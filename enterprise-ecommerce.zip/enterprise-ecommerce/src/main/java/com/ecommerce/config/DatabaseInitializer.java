package com.ecommerce.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.Statement;
import java.util.stream.Collectors;

/** Runs schema.sql / seed.sql against the configured database on startup. */
public final class DatabaseInitializer {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseInitializer.class);

    private DatabaseInitializer() {
    }

    public static void initialize() {
        runScript("database/schema.sql");
        runScript("database/seed.sql");
    }

    private static void runScript(String resourcePath) {
        try (InputStream in = DatabaseInitializer.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if (in == null) {
                logger.warn("SQL script not found on classpath: {}", resourcePath);
                return;
            }
            String script;
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                script = reader.lines().collect(Collectors.joining("\n"));
            }

            try (Connection conn = DatabaseConnectionPool.getInstance().getConnection();
                 Statement stmt = conn.createStatement()) {
                for (String rawStatement : script.split(";")) {
                    String sql = rawStatement.trim();
                    if (!sql.isEmpty()) {
                        stmt.execute(sql);
                    }
                }
            }
            logger.info("Executed SQL script: {}", resourcePath);
        } catch (Exception e) {
            logger.error("Failed to execute script {}: {}", resourcePath, e.getMessage(), e);
        }
    }
}
