package com.ecommerce.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Singleton pattern: exactly one connection pool exists for the whole
 * application's lifetime. Backed by HikariCP. Defaults to an embedded H2
 * database so the project runs out-of-the-box without a real MySQL server;
 * point it at MySQL in application.properties for production use.
 */
public final class DatabaseConnectionPool {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseConnectionPool.class);
    private static volatile DatabaseConnectionPool instance;

    private final HikariDataSource dataSource;

    private DatabaseConnectionPool() {
        Properties props = loadProperties();

        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(props.getProperty("db.url", "jdbc:h2:./data/ecommerce;AUTO_SERVER=TRUE"));
        config.setUsername(props.getProperty("db.username", "sa"));
        config.setPassword(props.getProperty("db.password", ""));
        config.setMaximumPoolSize(Integer.parseInt(props.getProperty("db.pool.maxSize", "10")));
        config.setMinimumIdle(Integer.parseInt(props.getProperty("db.pool.minIdle", "2")));
        config.setConnectionTimeout(Long.parseLong(props.getProperty("db.pool.connectionTimeoutMs", "30000")));
        config.setIdleTimeout(Long.parseLong(props.getProperty("db.pool.idleTimeoutMs", "600000")));
        config.setMaxLifetime(Long.parseLong(props.getProperty("db.pool.maxLifetimeMs", "1800000")));
        config.setPoolName("ecommerce-pool");

        this.dataSource = new HikariDataSource(config);
        logger.info("Database connection pool initialized: {}", config.getJdbcUrl());
    }

    private Properties loadProperties() {
        Properties props = new Properties();
        try (var in = getClass().getClassLoader().getResourceAsStream("application.properties")) {
            if (in != null) {
                props.load(in);
            }
        } catch (Exception e) {
            logger.warn("Could not load application.properties, using defaults: {}", e.getMessage());
        }
        return props;
    }

    public static DatabaseConnectionPool getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnectionPool.class) {
                if (instance == null) {
                    instance = new DatabaseConnectionPool();
                }
            }
        }
        return instance;
    }

    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    public void shutdown() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
            logger.info("Database connection pool shut down");
        }
    }
}
