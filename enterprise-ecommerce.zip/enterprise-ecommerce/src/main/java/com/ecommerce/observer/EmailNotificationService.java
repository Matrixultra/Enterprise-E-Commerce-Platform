package com.ecommerce.observer;

import com.ecommerce.model.Order;
import com.ecommerce.model.OrderStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EmailNotificationService implements OrderObserver {
    private static final Logger logger = LoggerFactory.getLogger(EmailNotificationService.class);

    @Override
    public void onOrderStatusChanged(Order order, OrderStatus newStatus) {
        logger.info("Email sent: order #{} status changed to {}", order.getId(), newStatus);
    }
}
