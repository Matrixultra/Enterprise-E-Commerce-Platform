package com.ecommerce.observer;

import com.ecommerce.model.Order;
import com.ecommerce.model.OrderStatus;

public interface OrderObserver {
    void onOrderStatusChanged(Order order, OrderStatus newStatus);
}
