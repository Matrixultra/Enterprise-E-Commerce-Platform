package com.ecommerce.factory;

/** Strategy-like interface used by the Factory pattern below. */
public interface PaymentProcessor {
    boolean processPayment(double amount, String currency);
    String getProcessorName();
}
