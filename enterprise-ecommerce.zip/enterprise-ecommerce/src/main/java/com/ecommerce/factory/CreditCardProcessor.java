package com.ecommerce.factory;

public class CreditCardProcessor implements PaymentProcessor {
    @Override
    public boolean processPayment(double amount, String currency) {
        System.out.printf("[CreditCard] Processing payment of %.2f %s%n", amount, currency);
        return amount > 0;
    }

    @Override
    public String getProcessorName() {
        return "CreditCardProcessor";
    }
}
