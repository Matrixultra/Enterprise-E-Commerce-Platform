package com.ecommerce.factory;

/** Classic Factory pattern: hides which concrete processor gets created. */
public class PaymentProcessorFactory {

    private PaymentProcessorFactory() {
    }

    public static PaymentProcessor createProcessor(String type) {
        if (type == null) {
            throw new IllegalArgumentException("Payment processor type must not be null");
        }
        switch (type.toLowerCase()) {
            case "creditcard":
                return new CreditCardProcessor();
            case "paypal":
                return new PayPalProcessor();
            case "stripe":
                return new StripeProcessor();
            default:
                throw new IllegalArgumentException("Unknown payment processor: " + type);
        }
    }
}
