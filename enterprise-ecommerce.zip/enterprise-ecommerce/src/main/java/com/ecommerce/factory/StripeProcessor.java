package com.ecommerce.factory;

public class StripeProcessor implements PaymentProcessor {
    @Override
    public boolean processPayment(double amount, String currency) {
        System.out.printf("[Stripe] Processing payment of %.2f %s%n", amount, currency);
        return amount > 0;
    }

    @Override
    public String getProcessorName() {
        return "StripeProcessor";
    }
}
