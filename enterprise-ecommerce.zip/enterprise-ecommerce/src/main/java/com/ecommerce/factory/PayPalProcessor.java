package com.ecommerce.factory;

public class PayPalProcessor implements PaymentProcessor {
    @Override
    public boolean processPayment(double amount, String currency) {
        System.out.printf("[PayPal] Processing payment of %.2f %s%n", amount, currency);
        return amount > 0;
    }

    @Override
    public String getProcessorName() {
        return "PayPalProcessor";
    }
}
