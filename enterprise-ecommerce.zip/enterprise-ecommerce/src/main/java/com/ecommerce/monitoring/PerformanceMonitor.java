package com.ecommerce.monitoring;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Thread-safe method-level performance tracker. Singleton-by-convention
 * (one shared instance), used to power the runtime performance report.
 */
public class PerformanceMonitor {

    private static final PerformanceMonitor INSTANCE = new PerformanceMonitor();

    private final Map<String, AtomicLong> totalTimeMs = new ConcurrentHashMap<>();
    private final Map<String, AtomicInteger> callCounts = new ConcurrentHashMap<>();

    private PerformanceMonitor() {
    }

    public static PerformanceMonitor getInstance() {
        return INSTANCE;
    }

    public void record(String methodName, long executionTimeMs) {
        totalTimeMs.computeIfAbsent(methodName, k -> new AtomicLong()).addAndGet(executionTimeMs);
        callCounts.computeIfAbsent(methodName, k -> new AtomicInteger()).incrementAndGet();
    }

    /** Convenience helper: times a Runnable and records it under the given label. */
    public void time(String methodName, Runnable action) {
        long start = System.currentTimeMillis();
        try {
            action.run();
        } finally {
            record(methodName, System.currentTimeMillis() - start);
        }
    }

    public void printReport() {
        System.out.println("\n=== PERFORMANCE REPORT ===");
        totalTimeMs.forEach((name, total) -> {
            int calls = callCounts.get(name).get();
            double avg = calls == 0 ? 0 : (double) total.get() / calls;
            System.out.printf("%-30s calls=%-6d total=%-8dms avg=%.2fms%n", name, calls, total.get(), avg);
        });
    }
}
