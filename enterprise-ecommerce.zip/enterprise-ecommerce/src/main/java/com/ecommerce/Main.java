package com.ecommerce;

import com.ecommerce.api.RestApiServer;
import com.ecommerce.config.DatabaseConnectionPool;
import com.ecommerce.config.DatabaseInitializer;
import com.ecommerce.model.Order;
import com.ecommerce.monitoring.PerformanceMonitor;
import com.ecommerce.repository.JdbcOrderRepository;
import com.ecommerce.repository.JdbcProductRepository;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.service.OrderService;
import com.ecommerce.service.PaymentService;
import com.ecommerce.service.ProductService;
import com.ecommerce.strategy.PercentageDiscountStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Application entry point: wires everything together and runs a demo. */
public class Main {

    private static final Logger logger = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {
        System.out.println("🏢 ENTERPRISE E-COMMERCE PLATFORM");
        System.out.println("===================================\n");

        // Initialize DB + schema (Singleton pattern: one pool for the whole app)
        DatabaseConnectionPool.getInstance();
        DatabaseInitializer.initialize();
        System.out.println("✅ Database connection pool initialized");

        ProductRepository productRepository = new JdbcProductRepository();
        OrderRepository orderRepository = new JdbcOrderRepository();

        ProductService productService = new ProductService(productRepository);
        PaymentService paymentService = new PaymentService();
        OrderService orderService = new OrderService(orderRepository, productService, paymentService);
        System.out.println("✅ Payment processor factory ready");
        System.out.println("✅ Order notification system ready");
        System.out.println("✅ Performance monitoring enabled\n");

        System.out.println("🛒 PRODUCT CATALOG:");
        List<com.ecommerce.model.Product> catalog = productService.getAllProducts();
        catalog.forEach(p -> System.out.println("  " + p));

        System.out.println("\n💰 PROCESSING A SAMPLE ORDER (multithreaded):");
        Map<Integer, Integer> items = new LinkedHashMap<>();
        items.put(101, 1);
        items.put(103, 2);

        try {
            Order order = orderService.createOrder(1, items, "creditcard", new PercentageDiscountStrategy(5));
            System.out.println("  " + order);
            order.getItems().forEach(i -> System.out.println("    - " + i));
            System.out.printf("  Subtotal: %.2f  Discount: %.2f  Tax: %.2f  Total: %.2f%n",
                    order.getSubtotal(), order.getDiscount(), order.getTax(), order.getTotal());
        } catch (Exception e) {
            logger.error("Demo order failed: {}", e.getMessage(), e);
        }

        PerformanceMonitor.getInstance().printReport();

        System.out.println("\n🌐 Starting REST API on http://localhost:8080 ...");
        try {
            RestApiServer apiServer = new RestApiServer(8080, productService, orderService);
            apiServer.start();
            System.out.println("  GET  /api/v1/products");
            System.out.println("  GET  /api/v1/products/{id}");
            System.out.println("  POST /api/v1/orders   body: {\"customerId\":1,\"items\":{\"101\":2},\"paymentMethod\":\"creditcard\"}");
            System.out.println("\nPress Ctrl+C to stop.");

            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                apiServer.stop();
                orderService.shutdown();
                DatabaseConnectionPool.getInstance().shutdown();
            }));
        } catch (Exception e) {
            logger.error("Could not start REST API: {}", e.getMessage(), e);
        }
    }
}
