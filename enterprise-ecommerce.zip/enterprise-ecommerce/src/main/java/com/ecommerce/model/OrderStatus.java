package com.ecommerce.model;

/** Lifecycle states for an Order. */
public enum OrderStatus {
    CREATED,
    PAYMENT_PENDING,
    PAID,
    PROCESSING,
    SHIPPED,
    DELIVERED,
    CANCELLED,
    FAILED
}
