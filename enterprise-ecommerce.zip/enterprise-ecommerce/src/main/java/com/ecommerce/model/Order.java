package com.ecommerce.model;

import com.ecommerce.observer.OrderObserver;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Order is the "Subject" in the Observer pattern: interested parties
 * (email/SMS notification services, audit logs, etc.) register themselves
 * and are notified whenever the order's status changes.
 */
public class Order {
    private int id;
    private int customerId;
    private final List<OrderItem> items = new ArrayList<>();
    private OrderStatus status = OrderStatus.CREATED;
    private double subtotal;
    private double discount;
    private double tax;
    private double total;
    private String paymentMethod;
    private LocalDateTime createdAt = LocalDateTime.now();

    private final transient List<OrderObserver> observers = new CopyOnWriteArrayList<>();

    public Order(int id, int customerId) {
        this.id = id;
        this.customerId = customerId;
    }

    public void addObserver(OrderObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(OrderObserver observer) {
        observers.remove(observer);
    }

    public void setStatus(OrderStatus newStatus) {
        this.status = newStatus;
        notifyObservers();
    }

    private void notifyObservers() {
        for (OrderObserver observer : observers) {
            observer.onOrderStatusChanged(this, status);
        }
    }

    public void addItem(OrderItem item) { items.add(item); }
    public List<OrderItem> getItems() { return Collections.unmodifiableList(items); }

    public int getId() { return id; }

    /** Only the persistence layer should reassign an id (e.g. after an INSERT generates one). */
    public void setId(int id) { this.id = id; }

    public int getCustomerId() { return customerId; }
    public OrderStatus getStatus() { return status; }

    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }

    public double getDiscount() { return discount; }
    public void setDiscount(double discount) { this.discount = discount; }

    public double getTax() { return tax; }
    public void setTax(double tax) { this.tax = tax; }

    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public LocalDateTime getCreatedAt() { return createdAt; }

    @Override
    public String toString() {
        return String.format("Order #%d [%s] total=%.2f items=%d", id, status, total, items.size());
    }
}
