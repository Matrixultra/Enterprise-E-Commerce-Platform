package com.ecommerce.repository;

import com.ecommerce.model.Order;

import java.util.List;
import java.util.Optional;

public interface OrderRepository {
    Order save(Order order);
    Optional<Order> findById(int id);
    List<Order> findAll();
    boolean updateStatus(int orderId, String status);
}
