package com.ecommerce.repository;

import com.ecommerce.config.DatabaseConnectionPool;
import com.ecommerce.model.Order;
import com.ecommerce.model.OrderItem;
import com.ecommerce.model.OrderStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class JdbcOrderRepository implements OrderRepository {

    private static final Logger logger = LoggerFactory.getLogger(JdbcOrderRepository.class);

    @Override
    public Order save(Order order) {
        String orderSql = "INSERT INTO orders (customer_id, status, subtotal, discount, tax, total, payment_method) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";
        String itemSql = "INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection c = DatabaseConnectionPool.getInstance().getConnection()) {
            c.setAutoCommit(false);
            try (PreparedStatement ps = c.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, order.getCustomerId());
                ps.setString(2, order.getStatus().name());
                ps.setDouble(3, order.getSubtotal());
                ps.setDouble(4, order.getDiscount());
                ps.setDouble(5, order.getTax());
                ps.setDouble(6, order.getTotal());
                ps.setString(7, order.getPaymentMethod());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        order.setId(keys.getInt(1));
                    }
                }
            }

            try (PreparedStatement ps = c.prepareStatement(itemSql)) {
                for (OrderItem item : order.getItems()) {
                    ps.setInt(1, order.getId());
                    ps.setInt(2, item.getProductId());
                    ps.setString(3, item.getProductName());
                    ps.setInt(4, item.getQuantity());
                    ps.setDouble(5, item.getUnitPrice());
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            c.commit();
        } catch (SQLException e) {
            logger.error("Failed to save order", e);
            throw new RuntimeException("Could not save order", e);
        }
        return order;
    }

    @Override
    public Optional<Order> findById(int id) {
        String sql = "SELECT id, customer_id, status, subtotal, discount, tax, total, payment_method FROM orders WHERE id = ?";
        try (Connection c = DatabaseConnectionPool.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapOrder(rs, c));
                }
            }
        } catch (SQLException e) {
            logger.error("findById failed for id={}", id, e);
        }
        return Optional.empty();
    }

    @Override
    public List<Order> findAll() {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT id, customer_id, status, subtotal, discount, tax, total, payment_method FROM orders ORDER BY id DESC";
        try (Connection c = DatabaseConnectionPool.getInstance().getConnection();
             Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                orders.add(mapOrder(rs, c));
            }
        } catch (SQLException e) {
            logger.error("findAll failed", e);
        }
        return orders;
    }

    @Override
    public boolean updateStatus(int orderId, String status) {
        String sql = "UPDATE orders SET status = ? WHERE id = ?";
        try (Connection c = DatabaseConnectionPool.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, orderId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            logger.error("updateStatus failed for orderId={}", orderId, e);
            return false;
        }
    }

    private Order mapOrder(ResultSet rs, Connection c) throws SQLException {
        Order order = new Order(rs.getInt("id"), rs.getInt("customer_id"));
        order.setStatus(OrderStatus.valueOf(rs.getString("status")));
        order.setSubtotal(rs.getDouble("subtotal"));
        order.setDiscount(rs.getDouble("discount"));
        order.setTax(rs.getDouble("tax"));
        order.setTotal(rs.getDouble("total"));
        order.setPaymentMethod(rs.getString("payment_method"));

        String itemSql = "SELECT product_id, product_name, quantity, unit_price FROM order_items WHERE order_id = ?";
        try (PreparedStatement ps = c.prepareStatement(itemSql)) {
            ps.setInt(1, order.getId());
            try (ResultSet irs = ps.executeQuery()) {
                while (irs.next()) {
                    order.addItem(new OrderItem(
                            irs.getInt("product_id"),
                            irs.getString("product_name"),
                            irs.getInt("quantity"),
                            irs.getDouble("unit_price")
                    ));
                }
            }
        }
        return order;
    }
}
