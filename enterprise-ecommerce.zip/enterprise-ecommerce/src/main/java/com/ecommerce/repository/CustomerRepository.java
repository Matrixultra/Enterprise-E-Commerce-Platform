package com.ecommerce.repository;

import com.ecommerce.model.Customer;

import java.util.Optional;

public interface CustomerRepository {
    Optional<Customer> findById(int id);
    Customer save(Customer customer);
}
