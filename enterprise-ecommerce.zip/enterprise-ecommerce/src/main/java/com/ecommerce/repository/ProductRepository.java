package com.ecommerce.repository;

import com.ecommerce.model.Product;

import java.util.List;
import java.util.Optional;

public interface ProductRepository {
    Optional<Product> findById(int id);
    List<Product> findAll();
    List<Product> findByCategory(String category);
    Product save(Product product);
    boolean updateStock(int productId, int delta);
    boolean deleteById(int id);
}
