package com.ecommerce.util;

import com.ecommerce.model.Order;
import com.ecommerce.model.OrderItem;
import com.ecommerce.model.Product;

import java.util.List;
import java.util.Map;

/**
 * Minimal, dependency-free JSON writer for the REST layer. Handles the
 * small set of domain objects this project exposes via the API; for a
 * larger surface area, swap this for Jackson (already on the classpath).
 */
public final class JsonUtil {

    private JsonUtil() {
    }

    public static String toJson(Product p) {
        return String.format(
                "{\"id\":%d,\"name\":%s,\"category\":%s,\"price\":%.2f,\"stock\":%d}",
                p.getId(), quote(p.getName()), quote(p.getCategory()), p.getPrice(), p.getStock());
    }

    public static String toJson(List<Product> products) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < products.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(toJson(products.get(i)));
        }
        return sb.append("]").toString();
    }

    public static String toJson(Order o) {
        StringBuilder items = new StringBuilder("[");
        List<OrderItem> orderItems = o.getItems();
        for (int i = 0; i < orderItems.size(); i++) {
            if (i > 0) items.append(",");
            OrderItem it = orderItems.get(i);
            items.append(String.format("{\"productId\":%d,\"productName\":%s,\"quantity\":%d,\"unitPrice\":%.2f}",
                    it.getProductId(), quote(it.getProductName()), it.getQuantity(), it.getUnitPrice()));
        }
        items.append("]");

        return String.format(
                "{\"id\":%d,\"customerId\":%d,\"status\":%s,\"subtotal\":%.2f,\"discount\":%.2f," +
                        "\"tax\":%.2f,\"total\":%.2f,\"paymentMethod\":%s,\"items\":%s}",
                o.getId(), o.getCustomerId(), quote(o.getStatus().name()), o.getSubtotal(), o.getDiscount(),
                o.getTax(), o.getTotal(), quote(o.getPaymentMethod()), items);
    }

    public static String errorJson(String message) {
        return String.format("{\"error\":%s}", quote(message));
    }

    public static String toJson(Map<String, Object> map) {
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, Object> e : map.entrySet()) {
            if (!first) sb.append(",");
            first = false;
            Object v = e.getValue();
            sb.append(quote(e.getKey())).append(":");
            if (v instanceof String) sb.append(quote((String) v));
            else sb.append(v);
        }
        return sb.append("}").toString();
    }

    private static String quote(String s) {
        if (s == null) return "null";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }
}
