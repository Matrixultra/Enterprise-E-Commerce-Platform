package com.ecommerce.strategy;

public interface DiscountStrategy {
    double applyDiscount(double originalPrice);
    String describe();
}
