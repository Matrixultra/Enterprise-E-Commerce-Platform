package com.ecommerce.api;

import com.ecommerce.service.OrderService;
import com.ecommerce.service.ProductService;
import com.sun.net.httpserver.HttpServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.Executors;

/**
 * Lightweight REST API built on the JDK's built-in HttpServer, so the
 * project has zero extra runtime dependencies for the web tier (no
 * application server required). Swap for Spring/Jersey if you need a
 * richer feature set -- the handlers below would translate almost 1:1.
 */
public class RestApiServer {

    private static final Logger logger = LoggerFactory.getLogger(RestApiServer.class);

    private final HttpServer httpServer;

    public RestApiServer(int port, ProductService productService, OrderService orderService) throws IOException {
        httpServer = HttpServer.create(new InetSocketAddress(port), 0);
        httpServer.createContext("/api/v1/products", new ProductHandler(productService));
        httpServer.createContext("/api/v1/orders", new OrderHandler(orderService, productService));
        httpServer.setExecutor(Executors.newFixedThreadPool(8));
    }

    public void start() {
        httpServer.start();
        logger.info("REST API listening on port {}", httpServer.getAddress().getPort());
    }

    public void stop() {
        httpServer.stop(1);
        logger.info("REST API stopped");
    }
}
