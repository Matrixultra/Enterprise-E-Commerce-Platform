package com.ecommerce.api;

import com.ecommerce.exception.OrderProcessingException;
import com.ecommerce.model.Order;
import com.ecommerce.service.OrderService;
import com.ecommerce.service.ProductService;
import com.ecommerce.strategy.NoDiscountStrategy;
import com.ecommerce.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Handles GET /api/v1/orders/{id} and POST /api/v1/orders.
 * Expects a tiny, hand-rolled JSON body for POST, e.g.:
 *   {"customerId":1,"items":{"101":2,"103":1},"paymentMethod":"creditcard"}
 */
public class OrderHandler implements HttpHandler {

    private static final Logger logger = LoggerFactory.getLogger(OrderHandler.class);
    private static final Pattern ITEM_PATTERN = Pattern.compile("\"(\\d+)\"\\s*:\\s*(\\d+)");
    private static final Pattern FIELD_PATTERN = Pattern.compile("\"(\\w+)\"\\s*:\\s*\"?([^,\"}]+)\"?");

    private final OrderService orderService;
    private final ProductService productService;

    public OrderHandler(OrderService orderService, ProductService productService) {
        this.orderService = orderService;
        this.productService = productService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        try {
            String method = exchange.getRequestMethod();
            if ("POST".equalsIgnoreCase(method)) {
                handleCreate(exchange);
            } else if ("GET".equalsIgnoreCase(method)) {
                respond(exchange, 200, "{\"message\":\"Use POST to create an order\"}");
            } else {
                respond(exchange, 405, JsonUtil.errorJson("Method not allowed"));
            }
        } catch (OrderProcessingException e) {
            respond(exchange, 400, JsonUtil.errorJson(e.getMessage()));
        } catch (Exception e) {
            logger.error("Error handling order request: {}", e.getMessage(), e);
            respond(exchange, 500, JsonUtil.errorJson("Internal server error"));
        }
    }

    private void handleCreate(HttpExchange exchange) throws IOException {
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);

        Map<String, String> fields = new LinkedHashMap<>();
        Matcher fm = FIELD_PATTERN.matcher(body);
        while (fm.find()) {
            fields.put(fm.group(1), fm.group(2));
        }

        int customerId = Integer.parseInt(fields.getOrDefault("customerId", "0"));
        String paymentMethod = fields.getOrDefault("paymentMethod", "creditcard");

        Map<Integer, Integer> items = new LinkedHashMap<>();
        Matcher im = ITEM_PATTERN.matcher(body);
        while (im.find()) {
            items.put(Integer.parseInt(im.group(1)), Integer.parseInt(im.group(2)));
        }

        Order order = orderService.createOrder(customerId, items, paymentMethod, new NoDiscountStrategy());
        respond(exchange, 201, JsonUtil.toJson(order));
    }

    private void respond(HttpExchange exchange, int status, String responseBody) throws IOException {
        byte[] bytes = responseBody.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
}
