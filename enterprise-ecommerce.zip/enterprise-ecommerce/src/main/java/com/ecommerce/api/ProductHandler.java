package com.ecommerce.api;

import com.ecommerce.exception.ProductNotFoundException;
import com.ecommerce.exception.ValidationException;
import com.ecommerce.model.Product;
import com.ecommerce.service.ProductService;
import com.ecommerce.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Handles GET /api/v1/products and GET /api/v1/products/{id}.
 * Mirrors the JAX-RS ProductResource from the design doc, but runs on
 * the plain JDK HTTP server so no app server / extra jars are required.
 */
public class ProductHandler implements HttpHandler {

    private static final Logger logger = LoggerFactory.getLogger(ProductHandler.class);
    private final ProductService productService;

    public ProductHandler(ProductService productService) {
        this.productService = productService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        try {
            String method = exchange.getRequestMethod();
            String path = exchange.getRequestURI().getPath();

            if ("GET".equalsIgnoreCase(method)) {
                String[] segments = path.split("/");
                if (segments.length > 4) {
                    int id = Integer.parseInt(segments[4]);
                    logger.info("Fetching product with id: {}", id);
                    Product product = productService.getProductById(id);
                    respond(exchange, 200, JsonUtil.toJson(product));
                } else {
                    respond(exchange, 200, JsonUtil.toJson(productService.getAllProducts()));
                }
            } else {
                respond(exchange, 405, JsonUtil.errorJson("Method not allowed"));
            }
        } catch (ProductNotFoundException e) {
            respond(exchange, 404, JsonUtil.errorJson(e.getMessage()));
        } catch (ValidationException | NumberFormatException e) {
            respond(exchange, 400, JsonUtil.errorJson(e.getMessage()));
        } catch (Exception e) {
            logger.error("Error handling product request: {}", e.getMessage(), e);
            respond(exchange, 500, JsonUtil.errorJson("Internal server error"));
        }
    }

    private void respond(HttpExchange exchange, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
}
