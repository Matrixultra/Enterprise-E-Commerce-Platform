package com.ecommerce.security;

import java.util.regex.Pattern;

/** Centralized input validation / sanitization used across services and the REST layer. */
public final class InputValidator {

    private static final Pattern SQL_INJECTION_PATTERN = Pattern.compile(
            "(['\";]|(--)|(/\\*)|(\\bunion\\b)|(\\bselect\\b)|(\\binsert\\b)|(\\bupdate\\b)|" +
                    "(\\bdelete\\b)|(\\bdrop\\b)|(\\bcreate\\b)|(\\balter\\b))",
            Pattern.CASE_INSENSITIVE);

    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");

    private InputValidator() {
    }

    public static boolean isValidEmail(String email) {
        return email != null && email.length() <= 100 && EMAIL_PATTERN.matcher(email).matches();
    }

    public static boolean isValidProductName(String name) {
        if (name == null) return false;
        String trimmed = name.trim();
        return trimmed.length() >= 2 && trimmed.length() <= 100 && !containsSuspiciousContent(trimmed);
    }

    public static boolean isValidPrice(double price) {
        return price >= 0 && price <= 1_000_000;
    }

    public static boolean isValidQuantity(int quantity) {
        return quantity > 0 && quantity <= 10_000;
    }

    public static boolean containsSuspiciousContent(String input) {
        return input != null && SQL_INJECTION_PATTERN.matcher(input).find();
    }

    /** Strips characters commonly used in HTML/script injection. Defense in depth, not a substitute for parameterized SQL. */
    public static String sanitize(String input) {
        if (input == null) return "";
        return input.replaceAll("[<>\"']", "").trim();
    }
}
