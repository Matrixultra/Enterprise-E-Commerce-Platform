package com.ecommerce.service;

import com.ecommerce.exception.PaymentException;
import com.ecommerce.factory.PaymentProcessor;
import com.ecommerce.factory.PaymentProcessorFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PaymentService {

    private static final Logger logger = LoggerFactory.getLogger(PaymentService.class);

    public boolean charge(String processorType, double amount, String currency) {
        PaymentProcessor processor = PaymentProcessorFactory.createProcessor(processorType);
        boolean success = processor.processPayment(amount, currency);
        if (!success) {
            throw new PaymentException("Payment failed via " + processor.getProcessorName());
        }
        logger.info("Payment of {} {} succeeded via {}", amount, currency, processor.getProcessorName());
        return true;
    }
}
