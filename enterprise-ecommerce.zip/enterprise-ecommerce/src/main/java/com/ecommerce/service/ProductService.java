package com.ecommerce.service;

import com.ecommerce.exception.ProductNotFoundException;
import com.ecommerce.exception.ValidationException;
import com.ecommerce.model.Product;
import com.ecommerce.monitoring.PerformanceMonitor;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.security.InputValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class ProductService {

    private static final Logger logger = LoggerFactory.getLogger(ProductService.class);

    private final ProductRepository productRepository;
    private final PerformanceMonitor monitor = PerformanceMonitor.getInstance();

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public Product getProductById(int id) {
        long start = System.currentTimeMillis();
        try {
            return productRepository.findById(id)
                    .orElseThrow(() -> new ProductNotFoundException(id));
        } finally {
            monitor.record("ProductService.getProductById", System.currentTimeMillis() - start);
        }
    }

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public List<Product> getProductsByCategory(String category) {
        return productRepository.findByCategory(category);
    }

    public Product createProduct(Product product) {
        if (!InputValidator.isValidProductName(product.getName())) {
            throw new ValidationException("Invalid product name: " + product.getName());
        }
        if (!InputValidator.isValidPrice(product.getPrice())) {
            throw new ValidationException("Invalid product price: " + product.getPrice());
        }
        Product saved = productRepository.save(product);
        logger.info("Created product: {}", saved);
        return saved;
    }

    /** Used by order processing to atomically decrement stock; returns false if insufficient stock. */
    public boolean reserveStock(int productId, int quantity) {
        if (!InputValidator.isValidQuantity(quantity)) {
            throw new ValidationException("Invalid quantity: " + quantity);
        }
        return productRepository.updateStock(productId, -quantity);
    }

    public double calculateTotalPrice(List<Product> products) {
        return products.stream().mapToDouble(Product::getPrice).sum();
    }
}
