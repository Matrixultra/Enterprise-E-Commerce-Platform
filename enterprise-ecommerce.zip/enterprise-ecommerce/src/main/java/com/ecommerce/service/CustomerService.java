package com.ecommerce.service;

import com.ecommerce.exception.ValidationException;
import com.ecommerce.model.Customer;
import com.ecommerce.repository.CustomerRepository;
import com.ecommerce.security.InputValidator;

import java.util.Optional;

public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public Optional<Customer> getCustomerById(int id) {
        return customerRepository.findById(id);
    }

    public Customer registerCustomer(Customer customer) {
        if (!InputValidator.isValidEmail(customer.getEmail())) {
            throw new ValidationException("Invalid email address: " + customer.getEmail());
        }
        return customerRepository.save(customer);
    }
}
