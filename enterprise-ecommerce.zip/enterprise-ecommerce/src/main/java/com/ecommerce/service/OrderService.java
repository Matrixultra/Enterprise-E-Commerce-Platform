package com.ecommerce.service;

import com.ecommerce.exception.OrderProcessingException;
import com.ecommerce.model.Order;
import com.ecommerce.model.OrderItem;
import com.ecommerce.model.OrderStatus;
import com.ecommerce.model.Product;
import com.ecommerce.monitoring.PerformanceMonitor;
import com.ecommerce.observer.EmailNotificationService;
import com.ecommerce.observer.OrderObserver;
import com.ecommerce.observer.SmsNotificationService;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.strategy.DiscountStrategy;
import com.ecommerce.strategy.NoDiscountStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Coordinates order creation end-to-end: stock reservation, discount
 * (Strategy), payment (delegates to PaymentService, which uses the Factory),
 * notifications (Observer), and persistence.
 *
 * Order processing runs on a bounded thread pool so multiple orders can be
 * validated/paid/persisted concurrently without one slow order blocking
 * the rest -- this is the "multithreading for order processing" requirement.
 */
public class OrderService {

    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);
    private static final double TAX_RATE = 0.18;

    private final OrderRepository orderRepository;
    private final ProductService productService;
    private final PaymentService paymentService;
    private final PerformanceMonitor monitor = PerformanceMonitor.getInstance();
    private final AtomicInteger orderIdSequence = new AtomicInteger(1);

    private final ExecutorService orderExecutor;
    private final List<OrderObserver> defaultObservers;

    public OrderService(OrderRepository orderRepository, ProductService productService,
                         PaymentService paymentService) {
        this.orderRepository = orderRepository;
        this.productService = productService;
        this.paymentService = paymentService;
        this.orderExecutor = new ThreadPoolExecutor(
                4, 8, 60, TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(100),
                runnable -> {
                    Thread t = new Thread(runnable, "order-worker");
                    t.setDaemon(true);
                    return t;
                }
        );
        this.defaultObservers = List.of(new EmailNotificationService(), new SmsNotificationService());
    }

    /** Submits an order for asynchronous processing; returns a Future the caller can wait on. */
    public Future<Order> submitOrderAsync(int customerId, Map<Integer, Integer> productQuantities,
                                           String paymentProcessorType, DiscountStrategy discountStrategy) {
        return orderExecutor.submit(() ->
                processOrder(customerId, productQuantities, paymentProcessorType, discountStrategy));
    }

    /** Synchronous convenience wrapper, used by the REST API and CLI demo. */
    public Order createOrder(int customerId, Map<Integer, Integer> productQuantities,
                              String paymentProcessorType, DiscountStrategy discountStrategy) {
        try {
            return submitOrderAsync(customerId, productQuantities, paymentProcessorType, discountStrategy).get();
        } catch (InterruptedException | ExecutionException e) {
            Thread.currentThread().interrupt();
            throw new OrderProcessingException("Order processing failed", e);
        }
    }

    private Order processOrder(int customerId, Map<Integer, Integer> productQuantities,
                                String paymentProcessorType, DiscountStrategy discountStrategy) {
        long start = System.currentTimeMillis();
        Order order = new Order(orderIdSequence.getAndIncrement(), customerId);
        defaultObservers.forEach(order::addObserver);

        try {
            double subtotal = 0;
            // Reserve stock for every line item up front; roll back on failure.
            for (Map.Entry<Integer, Integer> entry : productQuantities.entrySet()) {
                int productId = entry.getKey();
                int quantity = entry.getValue();
                Product product = productService.getProductById(productId);

                if (!productService.reserveStock(productId, quantity)) {
                    rollbackReservations(order);
                    throw new OrderProcessingException("Insufficient stock for product " + productId);
                }
                order.addItem(new OrderItem(productId, product.getName(), quantity, product.getPrice()));
                subtotal += product.getPrice() * quantity;
            }

            DiscountStrategy strategy = discountStrategy != null ? discountStrategy : new NoDiscountStrategy();
            double afterDiscount = strategy.applyDiscount(subtotal);
            double discountAmount = subtotal - afterDiscount;
            double tax = afterDiscount * TAX_RATE;
            double total = afterDiscount + tax;

            order.setSubtotal(subtotal);
            order.setDiscount(discountAmount);
            order.setTax(tax);
            order.setTotal(total);
            order.setPaymentMethod(paymentProcessorType);
            order.setStatus(OrderStatus.PAYMENT_PENDING);

            paymentService.charge(paymentProcessorType, total, "INR");
            order.setStatus(OrderStatus.PAID);

            orderRepository.save(order);
            order.setStatus(OrderStatus.PROCESSING);

            logger.info("Order processed successfully: {}", order);
            return order;

        } catch (Exception e) {
            order.setStatus(OrderStatus.FAILED);
            logger.error("Order processing failed for customer {}: {}", customerId, e.getMessage(), e);
            throw e instanceof OrderProcessingException ? (OrderProcessingException) e
                    : new OrderProcessingException("Order processing failed", e);
        } finally {
            monitor.record("OrderService.createOrder", System.currentTimeMillis() - start);
        }
    }

    private void rollbackReservations(Order order) {
        for (OrderItem item : order.getItems()) {
            productService.reserveStock(item.getProductId(), -item.getQuantity());
        }
    }

    public void shutdown() {
        orderExecutor.shutdown();
        try {
            if (!orderExecutor.awaitTermination(10, TimeUnit.SECONDS)) {
                orderExecutor.shutdownNow();
            }
        } catch (InterruptedException e) {
            orderExecutor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
