MERGE INTO customers (id, name, email, phone) VALUES (1, 'Alice Johnson', 'alice@email.com', '9876543210');
MERGE INTO customers (id, name, email, phone) VALUES (2, 'Bob Singh', 'bob@email.com', '9876500000');

MERGE INTO products (id, name, category, price, stock) VALUES (101, 'Gaming Laptop', 'Electronics', 85000.00, 25);
MERGE INTO products (id, name, category, price, stock) VALUES (102, 'Wireless Mouse', 'Electronics', 1200.00, 150);
MERGE INTO products (id, name, category, price, stock) VALUES (103, 'Java Programming Book', 'Books', 850.00, 75);
MERGE INTO products (id, name, category, price, stock) VALUES (104, 'Cotton T-Shirt', 'Clothing', 599.00, 200);
MERGE INTO products (id, name, category, price, stock) VALUES (105, 'Coffee Maker', 'Home', 3499.00, 50);
