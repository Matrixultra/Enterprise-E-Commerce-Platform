package com.ecommerce.service;

import com.ecommerce.exception.OrderProcessingException;
import com.ecommerce.model.Order;
import com.ecommerce.model.Product;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.strategy.PercentageDiscountStrategy;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;
    @Mock
    private ProductRepository productRepository;

    private ProductService productService;
    private OrderService orderService;

    @BeforeEach
    void setUp() {
        productService = new ProductService(productRepository);
        orderService = new OrderService(orderRepository, productService, new PaymentService());
    }

    @AfterEach
    void tearDown() {
        orderService.shutdown();
    }

    @Test
    void createOrder_succeedsAndAppliesDiscount() {
        Product laptop = new Product(101, "Laptop", "Electronics", 1000.0, 10);
        when(productRepository.findById(101)).thenReturn(Optional.of(laptop));
        when(productRepository.updateStock(101, -1)).thenReturn(true);
        when(orderRepository.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

        Map<Integer, Integer> items = new LinkedHashMap<>();
        items.put(101, 1);

        Order order = orderService.createOrder(1, items, "creditcard", new PercentageDiscountStrategy(10));

        assertEquals(1000.0, order.getSubtotal(), 0.001);
        assertEquals(100.0, order.getDiscount(), 0.001);
        verify(orderRepository).save(any(Order.class));
    }

    @Test
    void createOrder_failsWhenStockInsufficient() {
        Product laptop = new Product(101, "Laptop", "Electronics", 1000.0, 0);
        when(productRepository.findById(101)).thenReturn(Optional.of(laptop));
        when(productRepository.updateStock(101, -5)).thenReturn(false);

        Map<Integer, Integer> items = new LinkedHashMap<>();
        items.put(101, 5);

        assertThrows(OrderProcessingException.class,
                () -> orderService.createOrder(1, items, "creditcard", null));
        verify(orderRepository, never()).save(any());
    }

    @Test
    void multipleOrders_canBeProcessedConcurrently() throws Exception {
        Product book = new Product(103, "Book", "Books", 50.0, 1000);
        when(productRepository.findById(103)).thenReturn(Optional.of(book));
        when(productRepository.updateStock(eq(103), anyInt())).thenReturn(true);
        when(orderRepository.save(any(Order.class))).thenAnswer(inv -> inv.getArgument(0));

        Map<Integer, Integer> items = new LinkedHashMap<>();
        items.put(103, 1);

        var f1 = orderService.submitOrderAsync(1, items, "creditcard", null);
        var f2 = orderService.submitOrderAsync(2, items, "paypal", null);
        var f3 = orderService.submitOrderAsync(3, items, "stripe", null);

        assertNotNull(f1.get());
        assertNotNull(f2.get());
        assertNotNull(f3.get());
        verify(orderRepository, times(3)).save(any(Order.class));
    }
}
