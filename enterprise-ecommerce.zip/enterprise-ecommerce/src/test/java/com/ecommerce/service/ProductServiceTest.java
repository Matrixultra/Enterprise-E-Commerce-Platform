package com.ecommerce.service;

import com.ecommerce.exception.ProductNotFoundException;
import com.ecommerce.exception.ValidationException;
import com.ecommerce.model.Product;
import com.ecommerce.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    private ProductService productService;

    @BeforeEach
    void setUp() {
        productService = new ProductService(productRepository);
    }

    @Test
    void getProductById_returnsProduct_whenFound() {
        Product expected = new Product(1, "Laptop", "Electronics", 999.99, 10);
        when(productRepository.findById(1)).thenReturn(Optional.of(expected));

        Product actual = productService.getProductById(1);

        assertEquals(1, actual.getId());
        assertEquals("Laptop", actual.getName());
        assertEquals(999.99, actual.getPrice(), 0.001);
        verify(productRepository).findById(1);
    }

    @Test
    void getProductById_throws_whenNotFound() {
        when(productRepository.findById(999)).thenReturn(Optional.empty());

        assertThrows(ProductNotFoundException.class, () -> productService.getProductById(999));
    }

    @Test
    void calculateTotalPrice_sumsAllProductPrices() {
        List<Product> products = Arrays.asList(
                new Product(1, "P1", 100.0),
                new Product(2, "P2", 200.0),
                new Product(3, "P3", 300.0)
        );

        double total = productService.calculateTotalPrice(products);

        assertEquals(600.0, total, 0.001);
    }

    @Test
    void createProduct_rejectsInvalidName() {
        Product invalid = new Product(0, "X", "Electronics", 10.0, 5);

        assertThrows(ValidationException.class, () -> productService.createProduct(invalid));
        verify(productRepository, never()).save(any());
    }

    @Test
    void createProduct_rejectsNegativePrice() {
        Product invalid = new Product(0, "Valid Name", "Electronics", -5.0, 5);

        assertThrows(ValidationException.class, () -> productService.createProduct(invalid));
    }

    @Test
    void createProduct_savesValidProduct() {
        Product valid = new Product(0, "Valid Name", "Electronics", 49.99, 5);
        when(productRepository.save(any(Product.class))).thenAnswer(inv -> inv.getArgument(0));

        Product saved = productService.createProduct(valid);

        assertEquals("Valid Name", saved.getName());
        verify(productRepository).save(valid);
    }
}
