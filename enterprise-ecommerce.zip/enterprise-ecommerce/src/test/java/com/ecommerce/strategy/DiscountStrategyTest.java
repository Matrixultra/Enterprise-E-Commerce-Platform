package com.ecommerce.strategy;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class DiscountStrategyTest {

    @Test
    void percentageDiscount_appliesCorrectly() {
        DiscountStrategy strategy = new PercentageDiscountStrategy(10);
        assertEquals(90.0, strategy.applyDiscount(100.0), 0.001);
    }

    @Test
    void percentageDiscount_rejectsOutOfRangeValues() {
        assertThrows(IllegalArgumentException.class, () -> new PercentageDiscountStrategy(150));
    }

    @Test
    void fixedAmountDiscount_neverGoesNegative() {
        DiscountStrategy strategy = new FixedAmountDiscountStrategy(500);
        assertEquals(0.0, strategy.applyDiscount(100.0), 0.001);
    }

    @Test
    void fixedAmountDiscount_subtractsFlatAmount() {
        DiscountStrategy strategy = new FixedAmountDiscountStrategy(20);
        assertEquals(80.0, strategy.applyDiscount(100.0), 0.001);
    }

    @Test
    void noDiscount_returnsOriginalPrice() {
        DiscountStrategy strategy = new NoDiscountStrategy();
        assertEquals(100.0, strategy.applyDiscount(100.0), 0.001);
    }
}
