package com.ecommerce.security;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class InputValidatorTest {

    @Test
    void validEmails_areAccepted() {
        assertTrue(InputValidator.isValidEmail("alice@email.com"));
        assertTrue(InputValidator.isValidEmail("bob.smith+test@sub.domain.co"));
    }

    @Test
    void invalidEmails_areRejected() {
        assertFalse(InputValidator.isValidEmail("not-an-email"));
        assertFalse(InputValidator.isValidEmail(null));
        assertFalse(InputValidator.isValidEmail("missing@domain"));
    }

    @Test
    void productNames_withSqlKeywords_areRejected() {
        assertFalse(InputValidator.isValidProductName("DROP TABLE products"));
        assertFalse(InputValidator.isValidProductName("name'; DELETE FROM products; --"));
    }

    @Test
    void productNames_thatAreValid_areAccepted() {
        assertTrue(InputValidator.isValidProductName("Gaming Laptop"));
    }

    @Test
    void price_boundariesAreEnforced() {
        assertTrue(InputValidator.isValidPrice(0));
        assertTrue(InputValidator.isValidPrice(999999));
        assertFalse(InputValidator.isValidPrice(-1));
        assertFalse(InputValidator.isValidPrice(2_000_000));
    }

    @Test
    void sanitize_stripsDangerousCharacters() {
        assertEquals("scriptalert(1)/script", InputValidator.sanitize("<script>alert(1)</script>"));
    }
}
