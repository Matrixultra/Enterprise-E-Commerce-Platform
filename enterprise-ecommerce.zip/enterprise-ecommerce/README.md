# Enterprise E-Commerce Platform

A complete Java enterprise e-commerce backend built to demonstrate MVC
architecture, classic design patterns, multithreading, JDBC database
integration, a REST API, security/validation, performance monitoring,
automated testing, and a CI/CD + Docker deployment pipeline.

## ✅ What's implemented

- **MVC-style layered architecture** — `api` (controller) / `service`
  (business logic) / `repository` (data access) / `model` (domain).
- **Design patterns:** Singleton (`DatabaseConnectionPool`), Factory
  (`PaymentProcessorFactory`), Observer (`Order` + `OrderObserver`),
  Strategy (`DiscountStrategy`), Repository/DAO (`*Repository`).
- **Multithreading:** orders are processed on a bounded `ThreadPoolExecutor`
  so multiple orders can be validated, paid, and persisted concurrently;
  stock decrements use atomic SQL updates to stay race-free.
- **Database integration** with HikariCP connection pooling. Ships with an
  embedded H2 database (zero setup) and a MySQL driver/profile for production.
- **REST API** for products and orders, built on the JDK's built-in
  `HttpServer` — no extra application server required.
- **Security:** input validation and basic SQL-injection / XSS pattern
  rejection in `security/InputValidator`.
- **Logging & monitoring:** SLF4J + Logback, plus a custom
  `PerformanceMonitor` that tracks call counts and timing per method.
- **Testing:** JUnit 5 + Mockito unit tests for the service layer,
  discount strategies, and input validation, including a concurrency test
  that submits multiple orders in parallel.
- **Docker** (`docker/Dockerfile`, `docker/docker-compose.yml`) and a
  **GitHub Actions CI pipeline** (`.github/workflows/ci.yml`) that compiles,
  tests, and packages the app on every push.

## Project structure
```
enterprise-ecommerce/
├── pom.xml
├── src/
│   ├── main/java/com/ecommerce/
│   │   ├── api/          REST controllers (HttpServer handlers)
│   │   ├── config/       Singleton DB pool + schema bootstrap
│   │   ├── exception/    Custom exceptions
│   │   ├── factory/      Factory pattern (payment processors)
│   │   ├── model/        Domain models
│   │   ├── monitoring/   Performance tracking
│   │   ├── observer/     Observer pattern (order notifications)
│   │   ├── repository/   DAO / JDBC data access
│   │   ├── security/     Input validation
│   │   ├── service/      Business logic (incl. multithreaded OrderService)
│   │   ├── strategy/     Strategy pattern (discounts)
│   │   ├── util/         JSON helper
│   │   └── Main.java
│   ├── main/resources/
│   │   ├── application.properties
│   │   ├── logback.xml
│   │   └── database/ (schema.sql, seed.sql)
│   └── test/java/com/ecommerce/   JUnit 5 + Mockito tests
├── docker/                Dockerfile, docker-compose.yml
├── scripts/               build.sh, run.sh, deploy.sh
├── docs/                  architecture, api, deployment, user docs
└── .github/workflows/     CI pipeline
```

## Quick start

> Requires Java 17+ and Maven (or use the Maven wrapper of your choice).
> The default profile uses an embedded H2 database, so there's **no
> external database setup needed** to try it out.

```bash
mvn clean package
java -jar target/enterprise-ecommerce.jar
```

This prints a console demo (catalog, a sample order processed through the
full pipeline, a performance report) and then starts the REST API on
`http://localhost:8080`.

Try it:
```bash
curl http://localhost:8080/api/v1/products
curl -X POST http://localhost:8080/api/v1/orders \
  -H "Content-Type: application/json" \
  -d '{"customerId":1,"items":{"101":1,"103":2},"paymentMethod":"creditcard"}'
```

Run the test suite:
```bash
mvn test
```

Run with Docker (MySQL + app):
```bash
./scripts/deploy.sh
```

## Documentation
- [Architecture & design patterns](docs/architecture/ARCHITECTURE.md)
- [REST API reference](docs/api/API.md)
- [Deployment guide](docs/deployment/DEPLOYMENT.md)
- [User guide](docs/user/USER_GUIDE.md)

## A note on the database default
The sample code in the original spec assumed a live MySQL server. To make
this project actually runnable without any setup, the default profile uses
an embedded H2 database in MySQL-compatibility mode. Everything else
(schema, queries, connection pooling via HikariCP) is written exactly as it
would be against MySQL — switch the one JDBC URL in
`application.properties` and you're on real MySQL.

## License
MIT — see [LICENSE](LICENSE).
