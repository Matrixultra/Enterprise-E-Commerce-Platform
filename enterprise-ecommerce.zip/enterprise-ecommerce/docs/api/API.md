# REST API Reference

Base URL: `http://localhost:8080`

The API is intentionally dependency-free (built on the JDK's
`com.sun.net.httpserver.HttpServer`), so no application server is required.

## GET /api/v1/products
Returns all products.

**Response 200**
```json
[
  {"id":101,"name":"Gaming Laptop","category":"Electronics","price":85000.00,"stock":25}
]
```

## GET /api/v1/products/{id}
Returns a single product.

**Response 200** — product JSON (see above)
**Response 404**
```json
{"error":"Product not found with id: 999"}
```

## POST /api/v1/orders
Creates and processes an order synchronously (internally uses the
multithreaded order pipeline).

**Request body**
```json
{"customerId": 1, "items": {"101": 1, "103": 2}, "paymentMethod": "creditcard"}
```
`paymentMethod` is one of `creditcard`, `paypal`, `stripe`.

**Response 201**
```json
{
  "id": 1,
  "customerId": 1,
  "status": "PROCESSING",
  "subtotal": 86700.00,
  "discount": 0.00,
  "tax": 15606.00,
  "total": 102306.00,
  "paymentMethod": "creditcard",
  "items": [
    {"productId":101,"productName":"Gaming Laptop","quantity":1,"unitPrice":85000.00},
    {"productId":103,"productName":"Java Programming Book","quantity":2,"unitPrice":850.00}
  ]
}
```

**Response 400** — validation/stock/payment error
```json
{"error":"Insufficient stock for product 101"}
```

## Error format
All errors are returned as `{"error": "<message>"}` with an appropriate
HTTP status code (400, 404, 405, or 500).
