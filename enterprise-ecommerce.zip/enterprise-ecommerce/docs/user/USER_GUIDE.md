# User Guide

## Running the app
```bash
mvn clean package
java -jar target/enterprise-ecommerce.jar
```

On startup you'll see:
1. Database pool initialization and schema/seed data loading.
2. The seeded product catalog printed to the console.
3. A demo order processed end-to-end (stock reserved, discount applied,
   payment charged, notifications fired, order persisted).
4. A performance report (calls / total time / average time per method).
5. The REST API starting on port 8080.

## Using the API
List products:
```bash
curl http://localhost:8080/api/v1/products
```

Get one product:
```bash
curl http://localhost:8080/api/v1/products/101
```

Place an order:
```bash
curl -X POST http://localhost:8080/api/v1/orders \
  -H "Content-Type: application/json" \
  -d '{"customerId":1,"items":{"101":1,"103":2},"paymentMethod":"creditcard"}'
```

## Running tests
```bash
mvn test
```

## Stopping the app
`Ctrl+C` — a shutdown hook stops the REST API, the order-processing thread
pool, and the database connection pool cleanly.
