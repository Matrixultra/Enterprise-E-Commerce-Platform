# Deployment Guide

## Local development (zero setup)
The default profile uses an embedded H2 database, so you can run the app
with no external services:

```bash
mvn clean package
java -jar target/enterprise-ecommerce.jar
```

The app starts a console demo, prints a performance report, then starts
the REST API on port 8080.

## Switching to MySQL (production)
Edit `src/main/resources/application.properties`:

```properties
db.url=jdbc:mysql://localhost:3306/ecommerce_db?useSSL=false&serverTimezone=UTC
db.username=root
db.password=password
```

Make sure a MySQL 8 server is reachable at that URL and that the
`mysql-connector-java` dependency in `pom.xml` is on the classpath (it
already is).

## Docker
```bash
mvn clean package -DskipTests
docker compose -f docker/docker-compose.yml up -d --build
```
This starts a MySQL 8 container plus the app container, wired together via
environment variables. The app will be reachable at `http://localhost:8080`.

## CI/CD
`.github/workflows/ci.yml` runs on every push/PR to `main`: compiles, runs
the JUnit test suite, packages the shaded jar, and uploads it as a build
artifact. Extend the `Deploy` stage to push to your registry / target
environment of choice (the `scripts/deploy.sh` script shows a minimal
Docker Compose deploy as a starting point).

## Configuration reference
| Property | Default | Description |
|---|---|---|
| `db.url` | embedded H2 | JDBC URL |
| `db.username` / `db.password` | `sa` / empty | DB credentials |
| `db.pool.maxSize` | 10 | HikariCP max pool size |
| `server.port` | 8080 | REST API port (currently hardcoded in `Main`; wire up if you externalize it) |
