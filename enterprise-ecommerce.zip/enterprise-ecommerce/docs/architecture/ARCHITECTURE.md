# System Architecture

## Overview
The platform follows a layered MVC-style architecture:

```
api/          REST layer (JDK HttpServer handlers) — the "Controller"
service/      Business logic / use cases
repository/   Data access (DAO pattern over JDBC)
model/        Domain objects — the "Model"
factory/      Factory pattern: payment processor creation
observer/     Observer pattern: order status notifications
strategy/     Strategy pattern: pluggable discount calculations
config/       Singleton DB connection pool + schema bootstrap
security/     Input validation / sanitization
monitoring/   Performance tracking
util/         Small shared helpers (JSON writer)
exception/    Domain-specific exceptions
```

## Request flow (creating an order)
1. `OrderHandler` (api) parses the incoming JSON and calls `OrderService.createOrder`.
2. `OrderService` submits the work to a bounded `ThreadPoolExecutor` — order
   validation, stock reservation, payment, and persistence for *different*
   orders can run concurrently rather than serially.
3. For each line item, `ProductService` reads the product and atomically
   reserves stock (`UPDATE ... SET stock = stock + ? WHERE stock + ? >= 0`),
   so two concurrent orders can never oversell the same item.
4. The chosen `DiscountStrategy` (Strategy pattern) computes the discount.
5. `PaymentService` asks `PaymentProcessorFactory` (Factory pattern) for a
   concrete `PaymentProcessor` and charges the order total.
6. The order is persisted via `OrderRepository` (DAO/Repository pattern).
7. `Order.setStatus(...)` notifies all registered `OrderObserver`s (Observer
   pattern) — currently email and SMS notification stubs — every time the
   status changes (CREATED → PAYMENT_PENDING → PAID → PROCESSING ...).

## Design patterns used

| Pattern    | Where                                   | Why |
|------------|------------------------------------------|-----|
| Singleton  | `DatabaseConnectionPool`                 | Exactly one connection pool for the app's lifetime |
| Factory    | `PaymentProcessorFactory`                | Decouples callers from concrete payment processor classes |
| Observer   | `Order` + `OrderObserver` implementations | Decouples order status changes from notification channels |
| Strategy   | `DiscountStrategy` implementations        | Swappable discount algorithms without changing `OrderService` |
| Repository/DAO | `*Repository` interfaces + JDBC impls | Isolates SQL from business logic, makes services testable with mocks |

## Concurrency model
`OrderService` owns a `ThreadPoolExecutor` (4 core / 8 max threads, bounded
queue of 100). Each call to `createOrder` blocks the *caller* until that
order finishes, but multiple callers (e.g. concurrent HTTP requests) are
processed on separate worker threads. Database-level atomic `UPDATE`
statements protect stock counts from race conditions instead of
application-level locks, so the design scales to multiple app instances
behind a load balancer.

## Database schema
See `src/main/resources/database/schema.sql`. Four tables: `customers`,
`products`, `orders`, `order_items`. The default profile points at an
embedded H2 database (zero setup); switch `application.properties` to the
commented-out MySQL URL for production.
