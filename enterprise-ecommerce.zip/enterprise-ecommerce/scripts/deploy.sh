#!/usr/bin/env bash
set -e
echo "Building and deploying via Docker Compose..."
mvn clean package -DskipTests
docker compose -f docker/docker-compose.yml up -d --build
echo "Deployed. API available at http://localhost:8080"
