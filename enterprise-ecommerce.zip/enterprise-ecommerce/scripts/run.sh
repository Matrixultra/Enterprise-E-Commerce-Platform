#!/usr/bin/env bash
set -e
JAR=target/enterprise-ecommerce.jar
if [ ! -f "$JAR" ]; then
  echo "Jar not found, building first..."
  ./scripts/build.sh
fi
java -jar "$JAR"
