#!/usr/bin/env bash
set -e
echo "Building Enterprise E-Commerce Platform..."
mvn clean package
echo "Build complete: target/enterprise-ecommerce.jar"
